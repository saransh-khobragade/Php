<?php
$con=mysql_connect("mysql13.000webhost.com","a8095515_root","saransh998");
mysql_select_db('a8095515_just',$con);
?>