<html>
<head>
<link rel="stylesheet" type="text/css" href="../css/justclick.css">
</head>

<body>
<div id="mndiv">

<h4>Select area</h4>
<select>
<option>sector 1</option>
<option>sector 2</option>
<option>sector 3</option>
<option>sector 4</option>
<option>sector 5</option>
<option>sector 6</option>
</select>
<br>
<?php
$e=$_REQUEST['id'];
echo"$e hellojjjjjjjjj";
?>

<h1  align="center">MOVIES</h1>
<table width="70%" border="1" align="center">
<tr>
<th>Movies Names</th>
<th>Threater</th>
<th>Rating</th>
<tr>

<td>Ye jawani hai deewani</td>
<td>Vencateshwar</td>
<td>***</td>
</tr>

<tr>
<td>Man of steel</td>
<td>New Vasant</td>
<td>****</td>
</tr>

<tr>
<td>Shortcut Romeo</td>
<td>Chandra</td>
<td>**</td>
</tr>

<tr>
<td>Don2</td>
<td>Adlabs</td>
<td>***</td>
</tr>

<tr>
<td>Dhoom5</td>
<td>Mourya</td>
<td>*****</td>
</tr>

</table>


</div>

</body>

</html>